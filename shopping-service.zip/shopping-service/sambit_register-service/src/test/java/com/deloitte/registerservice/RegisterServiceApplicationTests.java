package com.deloitte.registerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
